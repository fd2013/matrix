import xbmcaddon

addon_id = xbmcaddon.Addon().getAddonInfo('id')

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/Wizard_DV/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/Wizard_DV/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = [addon_id, 'packages', 'backups']
