import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/Wizard_DV/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/Wizard_DV/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
