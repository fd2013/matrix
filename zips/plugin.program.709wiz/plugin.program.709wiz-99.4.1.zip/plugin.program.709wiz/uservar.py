import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/Wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/Wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
